# /home/ubuntu/create_admin_user.py
import os
import sys
import urllib.parse
from werkzeug.security import generate_password_hash
from sqlalchemy import create_engine, text

# Database connection details (same as in main.py)
db_user = os.getenv("DB_USERNAME", "postgres.qlhujkcbkxjuolesonne")
db_password_raw = os.getenv("DB_PASSWORD", "Wesl@2211")
db_password_encoded = urllib.parse.quote_plus(db_password_raw)
db_host = os.getenv("DB_HOST", "aws-0-sa-east-1.pooler.supabase.com")
db_port = os.getenv("DB_PORT", "5432")
db_name = os.getenv("DB_NAME", "postgres")

db_url = f"postgresql://{db_user}:{db_password_encoded}@{db_host}:{db_port}/{db_name}"

# User details
username = "wesley"
password_raw = "Wesl@2211"
full_name = "Wesley Admin"
email = "wesley@example.com" # Using a placeholder email
role = "admin"

# Hash the password
password_hash = generate_password_hash(password_raw)

# SQL statement to insert the user
sql = text("""
INSERT INTO users (username, password_hash, full_name, email, role, is_active)
VALUES (:username, :password_hash, :full_name, :email, :role, TRUE)
ON CONFLICT (username) DO UPDATE SET
  password_hash = EXCLUDED.password_hash,
  full_name = EXCLUDED.full_name,
  email = EXCLUDED.email,
  role = EXCLUDED.role,
  is_active = TRUE,
  updated_at = CURRENT_TIMESTAMP;
""")

try:
    engine = create_engine(db_url)
    with engine.connect() as connection:
        connection.execute(sql, {
            "username": username,
            "password_hash": password_hash,
            "full_name": full_name,
            "email": email,
            "role": role
        })
        connection.commit() # Explicitly commit the transaction
    print(f"User ", {username}, " created/updated successfully with admin role.")
except Exception as e:
    print(f"Error creating/updating user ", {username}, ": ", {e}, "")
    sys.exit(1) # Exit with error code if failed

