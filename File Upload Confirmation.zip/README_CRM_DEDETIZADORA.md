# Documentação do Sistema CRM para Dedetizadoras

Este documento fornece uma visão geral do sistema CRM desenvolvido, incluindo sua arquitetura, como configurar o ambiente de desenvolvimento e como utilizar a aplicação.

## Visão Geral

O sistema é composto por duas partes principais:

1.  **Backend:** Uma API RESTful desenvolvida com Flask (Python) que gerencia toda a lógica de negócios, interação com o banco de dados e autenticação.
2.  **Frontend:** Uma aplicação web responsiva desenvolvida com Next.js (React) que consome a API do backend e fornece a interface para o usuário.

O banco de dados utilizado é PostgreSQL, hospedado no Supabase (conforme solicitado).

## Arquitetura

*   **Backend (Flask):**
    *   Utiliza SQLAlchemy como ORM para interagir com o banco de dados PostgreSQL.
    *   Flask-JWT-Extended para autenticação baseada em tokens.
    *   Estrutura modular com Blueprints para organizar as rotas (Auth, Clientes, Serviços, Garantias, Notificações, Dashboard).
    *   Geração de certificados PDF com WeasyPrint.
    *   Conexão com o banco de dados configurada em `src/main.py`.
*   **Frontend (Next.js):**
    *   Utiliza React com TypeScript.
    *   Componentes de UI baseados em Tailwind CSS e shadcn/ui.
    *   Integração com a API do backend para buscar e enviar dados.
    *   Roteamento baseado em arquivos do Next.js.
    *   Integração com `@react-google-maps/api` para visualização de mapas.
*   **Banco de Dados (PostgreSQL/Supabase):**
    *   Schema definido no arquivo `database_schema_postgres.sql`.
    *   Tabelas para Usuários, Clientes, Serviços, Fotos de Serviços, Garantias e Notificações.
    *   Triggers para atualizar automaticamente os campos `updated_at`.

## Configuração do Ambiente de Desenvolvimento

### Pré-requisitos

*   Python 3.10+
*   Node.js 20+
*   pnpm (gerenciador de pacotes Node.js)
*   Acesso a um banco de dados PostgreSQL (como o Supabase configurado)

### Backend (Flask)

1.  **Clone o repositório (ou descompacte os arquivos).**
2.  **Navegue até o diretório `crm_dedetizadora_backend`:**
    ```bash
    cd /home/ubuntu/crm_dedetizadora_backend
    ```
3.  **Crie e ative um ambiente virtual:**
    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```
4.  **Instale as dependências:**
    ```bash
    pip install -r requirements.txt
    ```
5.  **Configure as variáveis de ambiente (se necessário):** O código está configurado para usar as credenciais do Supabase fornecidas. Se precisar alterar, modifique as variáveis de ambiente `DB_USERNAME`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT`, `DB_NAME` ou edite diretamente o arquivo `src/main.py` (não recomendado para produção).
6.  **Aplique o schema do banco de dados:** Certifique-se de que o script `database_schema_postgres.sql` foi executado no seu banco de dados Supabase.
7.  **Execute o servidor de desenvolvimento:**
    ```bash
    python src/main.py
    ```
    O backend estará rodando em `http://localhost:5001`.

### Frontend (Next.js)

1.  **Navegue até o diretório `crm_dedetizadora_frontend`:**
    ```bash
    cd /home/ubuntu/crm_dedetizadora_frontend
    ```
2.  **Instale as dependências:**
    ```bash
    pnpm install
    ```
3.  **Configure a URL da API do backend (se necessário):** O frontend tentará se conectar à API em `http://localhost:5001` por padrão. Se o backend estiver rodando em um endereço diferente, você precisará ajustar as chamadas de API nos componentes do frontend (geralmente em arquivos dentro de `src/lib` ou nos próprios componentes que fazem fetch).
4.  **Execute o servidor de desenvolvimento:**
    ```bash
    pnpm dev
    ```
    O frontend estará rodando em `http://localhost:3000`.

## Uso Básico

1.  Acesse o frontend (normalmente `http://localhost:3000`).
2.  Faça login com um usuário existente (como o usuário `wesley` criado).
3.  Navegue pelas seções usando o menu lateral:
    *   **Dashboard:** Visão geral com KPIs.
    *   **Clientes:** Liste, crie, visualize e edite clientes.
    *   **Serviços:** Registre novos serviços associados a clientes.
    *   **Garantias:** Crie garantias para serviços e visualize/baixe certificados PDF.

## Próximos Passos da Documentação

*   Detalhar os endpoints da API.
*   Criar um guia do usuário mais detalhado com screenshots.
*   Adicionar informações sobre deployment (se aplicável).

