// /home/ubuntu/crm_dedetizadora_frontend/src/components/clients/ClientForm.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea"; // Assuming Textarea exists

// Define the structure for client data (subset for the form)
interface ClientFormData {
  name: string;
  phone?: string;
  email?: string;
  address_street?: string;
  address_number?: string;
  address_complement?: string;
  address_neighborhood?: string;
  address_city?: string;
  address_state?: string;
  address_zipcode?: string;
  segment: "Residencial" | "Comercial" | "Condomínio" | "Industrial" | "";
  // address_latitude and address_longitude might be handled separately (e.g., map input)
}

interface ClientFormProps {
  initialData?: ClientFormData & { client_id?: number }; // Include client_id if editing
  isEditing: boolean;
  onSubmit: (data: ClientFormData) => Promise<void>; // Function to handle API call
  isLoading: boolean;
  error: string | null;
}

export default function ClientForm({ initialData, isEditing, onSubmit, isLoading, error }: ClientFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState<ClientFormData>({
    name: "",
    phone: "",
    email: "",
    address_street: "",
    address_number: "",
    address_complement: "",
    address_neighborhood: "",
    address_city: "",
    address_state: "",
    address_zipcode: "",
    segment: "",
    ...(initialData || {}), // Spread initial data if provided
  });

  useEffect(() => {
    // Update form data if initialData changes (e.g., when editing)
    if (initialData) {
      setFormData({
        name: initialData.name || "",
        phone: initialData.phone || "",
        email: initialData.email || "",
        address_street: initialData.address_street || "",
        address_number: initialData.address_number || "",
        address_complement: initialData.address_complement || "",
        address_neighborhood: initialData.address_neighborhood || "",
        address_city: initialData.address_city || "",
        address_state: initialData.address_state || "",
        address_zipcode: initialData.address_zipcode || "",
        segment: initialData.segment || "",
      });
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    // Ensure the value matches the allowed enum types
    if ([ "Residencial", "Comercial", "Condomínio", "Industrial"].includes(value)) {
        setFormData((prev) => ({ ...prev, segment: value as ClientFormData["segment"] }));
    } else {
        setFormData((prev) => ({ ...prev, segment: "" }));
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    await onSubmit(formData);
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>{isEditing ? "Editar Cliente" : "Adicionar Novo Cliente"}</CardTitle>
        <CardDescription>
          Preencha as informações do cliente abaixo.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Column 1 */}
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nome Completo *</Label>
              <Input
                id="name"
                name="name"
                placeholder="Nome do Cliente ou Razão Social"
                required
                value={formData.name}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="segment">Segmento *</Label>
              <Select
                required
                value={formData.segment}
                onValueChange={handleSelectChange}
                disabled={isLoading}
              >
                <SelectTrigger id="segment" name="segment">
                  <SelectValue placeholder="Selecione o segmento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Residencial">Residencial</SelectItem>
                  <SelectItem value="Comercial">Comercial</SelectItem>
                  <SelectItem value="Condomínio">Condomínio</SelectItem>
                  <SelectItem value="Industrial">Industrial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                placeholder="(XX) XXXXX-XXXX"
                value={formData.phone}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="cliente@email.com"
                value={formData.email}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Column 2 */}
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="address_zipcode">CEP</Label>
              <Input
                id="address_zipcode"
                name="address_zipcode"
                placeholder="00000-000"
                value={formData.address_zipcode}
                onChange={handleChange}
                disabled={isLoading}
                // TODO: Add CEP lookup functionality here
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="address_street">Endereço (Rua/Av.)</Label>
              <Input
                id="address_street"
                name="address_street"
                placeholder="Rua Exemplo, Avenida Principal"
                value={formData.address_street}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
                <div className="grid gap-2 col-span-1">
                    <Label htmlFor="address_number">Número</Label>
                    <Input
                        id="address_number"
                        name="address_number"
                        placeholder="123"
                        value={formData.address_number}
                        onChange={handleChange}
                        disabled={isLoading}
                    />
                </div>
                <div className="grid gap-2 col-span-2">
                    <Label htmlFor="address_complement">Complemento</Label>
                    <Input
                        id="address_complement"
                        name="address_complement"
                        placeholder="Apto 101, Bloco B"
                        value={formData.address_complement}
                        onChange={handleChange}
                        disabled={isLoading}
                    />
                </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="address_neighborhood">Bairro</Label>
              <Input
                id="address_neighborhood"
                name="address_neighborhood"
                placeholder="Centro, Vila Nova"
                value={formData.address_neighborhood}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
                <div className="grid gap-2 col-span-2">
                    <Label htmlFor="address_city">Cidade</Label>
                    <Input
                        id="address_city"
                        name="address_city"
                        placeholder="São Paulo, Rio de Janeiro"
                        value={formData.address_city}
                        onChange={handleChange}
                        disabled={isLoading}
                    />
                </div>
                <div className="grid gap-2 col-span-1">
                    <Label htmlFor="address_state">Estado</Label>
                    <Input
                        id="address_state"
                        name="address_state"
                        placeholder="SP, RJ"
                        value={formData.address_state}
                        onChange={handleChange}
                        disabled={isLoading}
                    />
                </div>
            </div>
             {/* TODO: Add Google Maps integration for lat/lng if needed */}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          {error && (
            <p className="text-sm text-red-600 dark:text-red-400">Erro: {error}</p>
          )}
          <div className="flex gap-2 ml-auto">
             <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
                Cancelar
             </Button>
             <Button type="submit" disabled={isLoading}>
                {isLoading ? (isEditing ? "Salvando..." : "Adicionando...") : (isEditing ? "Salvar Alterações" : "Adicionar Cliente")}
             </Button>
          </div>
        </CardFooter>
      </form>
    </Card>
  );
}

