// /home/ubuntu/crm_dedetizadora_frontend/src/components/layout/AppLayout.tsx
"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Home, // Dashboard
  Users, // Clientes
  Wrench, // Serviços
  ShieldCheck, // Garantias
  Bell, // Notificações
  Settings, // Configurações (Placeholder)
  LogOut, // Sair
  Menu, // Mobile Menu
  Sun, Moon // Theme Toggle
} from "lucide-react";
import { useTheme } from "next-themes";

interface UserInfo {
  full_name: string;
  role: string;
}

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: Home },
  { href: "/clients", label: "Clientes", icon: Users },
  { href: "/services", label: "Serviços", icon: Wrench }, // Assuming /services list page exists or will be created
  { href: "/guarantees", label: "Garantias", icon: ShieldCheck }, // Assuming /guarantees list page exists or will be created
  // { href: "/notifications", label: "Notificações", icon: Bell }, // Add later if needed
  // { href: "/settings", label: "Configurações", icon: Settings }, // Add later if needed
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);

  useEffect(() => {
    // Fetch or decode user info from token
    const token = localStorage.getItem("accessToken");
    if (token) {
      try {
        const payloadBase64 = token.split(".")[1];
        const decodedPayload = JSON.parse(atob(payloadBase64));
        setUserInfo({
          full_name: decodedPayload.full_name || "Usuário",
          role: decodedPayload.role || "Desconhecido",
        });
      } catch (error) {
        console.error("Failed to decode token:", error);
        handleLogout(); // Logout if token is invalid
      }
    } else {
        // Redirect to login if no token found on initial load of a protected route
        // This check might be redundant if pages handle it, but good as a fallback
        if (pathname !== 
/login
) { // Avoid redirect loop on login page
             router.push("/login");
        }
    }
  }, [pathname, router]); // Rerun on pathname change to handle potential token expiry during navigation

  const handleLogout = () => {
    localStorage.removeItem("accessToken");
    router.push("/login");
  };

  // Don't render layout on login page
  if (pathname === "/login") {
    return <>{children}</>;
  }

  // Render loading state or null if user info is not yet available
  // This prevents brief flashes of the layout before potential redirect
  if (!userInfo && pathname !== 
/login
) {
      return <div>Carregando...</div>; // Or a proper loading component
  }

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold">CRM Dedetizadora</h2>
      </div>
      <nav className="flex-1 px-2 py-4 space-y-1">
        {navItems.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
              ${pathname.startsWith(item.href) // Use startsWith for active state on sub-pages
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"}`}
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t mt-auto">
        <div className="mb-2">
            <p className="text-sm font-medium">{userInfo?.full_name}</p>
            <p className="text-xs text-muted-foreground">{userInfo?.role}</p>
        </div>
        <Button variant="outline" size="sm" className="w-full" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Sair
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:flex-shrink-0">
        <div className="flex flex-col w-64 border-r">
          <SidebarContent />
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <SidebarContent />
            </SheetContent>
          </Sheet>
          <h2 className="text-lg font-semibold">CRM Dedetizadora</h2>
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}

