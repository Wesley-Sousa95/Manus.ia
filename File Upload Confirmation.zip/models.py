# /home/ubuntu/crm_dedetizadora_backend/src/models/models.py

import sys
import os
# Adiciona o diretório pai de 'src' ao sys.path para permitir importações absolutas
# Isso é necessário porque os modelos podem ser importados por diferentes partes da aplicação (rotas, main.py)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Enum, ForeignKey, DECIMAL, Text, DateTime, func
from sqlalchemy.orm import relationship
import datetime

# Inicializa a extensão SQLAlchemy. A instância 'app' será vinculada posteriormente em main.py
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    role = db.Column(Enum('admin', 'manager', 'technician', name='user_roles'), nullable=False, default='technician')
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(DateTime(timezone=True), server_default=func.now())
    updated_at = db.Column(DateTime(timezone=True), default=func.now(), onupdate=func.now())

    # Relacionamentos
    created_clients = relationship("Client", back_populates="creator")
    performed_services = relationship("Service", back_populates="performer")
    notifications_assigned = relationship("Notification", back_populates="assigned_user")

class Client(db.Model):
    __tablename__ = 'clients'
    client_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False, index=True)
    phone = db.Column(db.String(20), index=True)
    email = db.Column(db.String(100), index=True)
    address_street = db.Column(db.String(255))
    address_number = db.Column(db.String(20))
    address_complement = db.Column(db.String(100))
    address_neighborhood = db.Column(db.String(100))
    address_city = db.Column(db.String(100))
    address_state = db.Column(db.String(50))
    address_zipcode = db.Column(db.String(15))
    address_latitude = db.Column(DECIMAL(10, 8))
    address_longitude = db.Column(DECIMAL(11, 8))
    segment = db.Column(Enum('Residencial', 'Comercial', 'Condomínio', 'Industrial', name='client_segments'), nullable=False)
    created_by_user_id = db.Column(db.Integer, ForeignKey('users.user_id', ondelete='SET NULL'))
    created_at = db.Column(DateTime(timezone=True), server_default=func.now())
    updated_at = db.Column(DateTime(timezone=True), default=func.now(), onupdate=func.now())

    # Relacionamentos
    creator = relationship("User", back_populates="created_clients")
    services = relationship("Service", back_populates="client", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="client", cascade="all, delete-orphan")

class Pest(db.Model):
    __tablename__ = 'pests'
    pest_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(Text)

    # Relacionamento (se usado em Service)
    # services = relationship("Service", back_populates="pest")

class Product(db.Model):
    __tablename__ = 'products'
    product_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(Text)

class Service(db.Model):
    __tablename__ = 'services'
    service_id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, ForeignKey('clients.client_id', ondelete='CASCADE'), nullable=False)
    service_date = db.Column(DateTime(timezone=True), nullable=False, index=True)
    pest_type_description = db.Column(db.String(255))
    # pest_id = db.Column(db.Integer, ForeignKey('pests.pest_id', ondelete='SET NULL')) # Uncomment if using Pest model
    location_details = db.Column(db.String(255))
    products_used_description = db.Column(Text)
    notes = db.Column(Text)
    performed_by_user_id = db.Column(db.Integer, ForeignKey('users.user_id', ondelete='SET NULL'))
    created_at = db.Column(DateTime(timezone=True), server_default=func.now())
    updated_at = db.Column(DateTime(timezone=True), default=func.now(), onupdate=func.now())

    # Relacionamentos
    client = relationship("Client", back_populates="services")
    performer = relationship("User", back_populates="performed_services")
    # pest = relationship("Pest", back_populates="services") # Uncomment if using Pest model
    photos = relationship("ServicePhoto", back_populates="service", cascade="all, delete-orphan")
    guarantee = relationship("Guarantee", back_populates="service", uselist=False, cascade="all, delete-orphan") # One-to-one

class ServicePhoto(db.Model):
    __tablename__ = 'service_photos'
    photo_id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, ForeignKey('services.service_id', ondelete='CASCADE'), nullable=False)
    photo_url = db.Column(db.String(512), nullable=False)
    description = db.Column(db.String(100))
    uploaded_at = db.Column(DateTime(timezone=True), server_default=func.now())

    # Relacionamento
    service = relationship("Service", back_populates="photos")

class Guarantee(db.Model):
    __tablename__ = 'guarantees'
    guarantee_id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, ForeignKey('services.service_id', ondelete='CASCADE'), unique=True, nullable=False)
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False, index=True)
    duration_months = db.Column(db.Integer)
    certificate_url = db.Column(db.String(512))
    created_at = db.Column(DateTime(timezone=True), server_default=func.now())
    updated_at = db.Column(DateTime(timezone=True), default=func.now(), onupdate=func.now())

    # Relacionamentos
    service = relationship("Service", back_populates="guarantee")
    notifications = relationship("Notification", back_populates="guarantee", cascade="all, delete-orphan")

class Notification(db.Model):
    __tablename__ = 'notifications'
    notification_id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, ForeignKey('clients.client_id', ondelete='CASCADE'))
    guarantee_id = db.Column(db.Integer, ForeignKey('guarantees.guarantee_id', ondelete='SET NULL'))
    user_id = db.Column(db.Integer, ForeignKey('users.user_id', ondelete='CASCADE')) # User to notify internally
    notification_type = db.Column(Enum('GuaranteeExpiry', 'RevisitReminder', 'Custom', name='notification_types'), nullable=False)
    channel = db.Column(Enum('Email', 'WhatsApp', 'InApp', 'System', name='notification_channels'), nullable=False)
    recipient = db.Column(db.String(255)) # Email, phone, user ID, etc.
    subject = db.Column(db.String(255))
    message = db.Column(Text, nullable=False)
    scheduled_send_date = db.Column(DateTime(timezone=True), index=True)
    actual_send_date = db.Column(DateTime(timezone=True), nullable=True)
    status = db.Column(Enum('Pending', 'Sent', 'Failed', 'Cancelled', name='notification_statuses'), nullable=False, default='Pending', index=True)
    error_message = db.Column(Text)
    created_at = db.Column(DateTime(timezone=True), server_default=func.now())
    updated_at = db.Column(DateTime(timezone=True), default=func.now(), onupdate=func.now())

    # Relacionamentos
    client = relationship("Client", back_populates="notifications")
    guarantee = relationship("Guarantee", back_populates="notifications")
    assigned_user = relationship("User", back_populates="notifications_assigned")


