// /home/ubuntu/crm_dedetizadora_frontend/src/components/guarantees/GuaranteeForm.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

// Define structure for guarantee form data
interface GuaranteeFormData {
  service_id: number | "";
  start_date: string; // Store as string for input type="date"
  end_date: string;   // Store as string for input type="date"
  duration_months?: number; // Optional, can be calculated
  certificate_url?: string; // Optional
}

interface GuaranteeFormProps {
  initialData?: GuaranteeFormData & { guarantee_id?: number };
  serviceId: number; // Service ID is required to link the guarantee
  clientName?: string; // Optional client name for display
  serviceDate?: string; // Optional service date for display
  isEditing: boolean;
  onSubmit: (data: GuaranteeFormData) => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

export default function GuaranteeForm({
  initialData,
  serviceId,
  clientName,
  serviceDate,
  isEditing,
  onSubmit,
  isLoading,
  error,
}: GuaranteeFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState<GuaranteeFormData>({
    service_id: serviceId || "", // Pre-fill service ID
    start_date: new Date().toISOString().slice(0, 10), // Default to today YYYY-MM-DD
    end_date: "",
    duration_months: undefined,
    certificate_url: "",
    ...(initialData || {}),
  });

  useEffect(() => {
    // Ensure serviceId is set from props
    if (serviceId && formData.service_id !== serviceId) {
        setFormData(prev => ({ ...prev, service_id: serviceId }));
    }
    // Update form data if initialData changes (e.g., when editing)
    if (initialData) {
      setFormData({
        service_id: initialData.service_id || serviceId || "",
        start_date: initialData.start_date ? new Date(initialData.start_date).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
        end_date: initialData.end_date ? new Date(initialData.end_date).toISOString().slice(0, 10) : "",
        duration_months: initialData.duration_months,
        certificate_url: initialData.certificate_url || "",
      });
    }
  }, [initialData, serviceId]); // Add serviceId dependency

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
        ...prev,
        [name]: type === "number" ? (value === "" ? undefined : parseInt(value, 10)) : value
    }));

    // Auto-calculate end_date if start_date and duration_months are set
    if (name === "start_date" || name === "duration_months") {
        const newStartDate = name === "start_date" ? value : formData.start_date;
        const newDuration = name === "duration_months" ? (value === "" ? undefined : parseInt(value, 10)) : formData.duration_months;

        if (newStartDate && newDuration !== undefined && newDuration > 0) {
            const startDateObj = new Date(newStartDate);
            startDateObj.setMonth(startDateObj.getMonth() + newDuration);
            // Adjust for potential day overflow if needed, though setMonth handles month wrapping
            const newEndDate = startDateObj.toISOString().slice(0, 10);
            setFormData(prev => ({ ...prev, end_date: newEndDate }));
        }
    }
     // Auto-calculate duration_months if start_date and end_date are set
    else if (name === "end_date") {
        const newEndDate = value;
        if (formData.start_date && newEndDate) {
            const startDateObj = new Date(formData.start_date);
            const endDateObj = new Date(newEndDate);
            if (endDateObj > startDateObj) {
                let months = (endDateObj.getFullYear() - startDateObj.getFullYear()) * 12;
                months -= startDateObj.getMonth();
                months += endDateObj.getMonth();
                // Basic month difference, might need refinement for exact day counts
                const duration = months <= 0 ? 0 : months;
                setFormData(prev => ({ ...prev, duration_months: duration }));
            }
        }
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!formData.service_id) {
        alert("Erro: ID do Serviço não encontrado.");
        return;
    }
    if (!formData.start_date || !formData.end_date) {
        alert("Por favor, preencha as datas de início e fim da garantia.");
        return;
    }
     if (new Date(formData.end_date) <= new Date(formData.start_date)) {
        alert("A data final deve ser posterior à data inicial.");
        return;
    }
    await onSubmit(formData);
  };

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader>
        <CardTitle>{isEditing ? "Editar Garantia" : "Adicionar Garantia ao Serviço"}</CardTitle>
        <CardDescription>
          Defina o período de garantia para o serviço #{serviceId}.
          {clientName && serviceDate && (
            <span className="block text-sm text-muted-foreground mt-1">
              Cliente: {clientName} | Serviço em: {new Date(serviceDate).toLocaleDateString("pt-BR")}
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {/* Service ID is usually hidden or just displayed */}
          <input type="hidden" name="service_id" value={formData.service_id} />

          <div className="grid gap-2">
            <Label htmlFor="start_date">Data de Início *</Label>
            <Input
              id="start_date"
              name="start_date"
              type="date"
              required
              value={formData.start_date}
              onChange={handleChange}
              disabled={isLoading}
            />
          </div>

          <div className="grid grid-cols-2 gap-4 items-end">
             <div className="grid gap-2">
                <Label htmlFor="duration_months">Duração (Meses)</Label>
                <Input
                id="duration_months"
                name="duration_months"
                type="number"
                min="0"
                placeholder="Ex: 6, 12, 24"
                value={formData.duration_months === undefined ? "" : formData.duration_months}
                onChange={handleChange}
                disabled={isLoading}
                />
            </div>
             <div className="grid gap-2">
                <Label htmlFor="end_date">Data Final *</Label>
                <Input
                id="end_date"
                name="end_date"
                type="date"
                required
                value={formData.end_date}
                onChange={handleChange}
                disabled={isLoading}
                />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="certificate_url">Link do Certificado (Opcional)</Label>
            <Input
              id="certificate_url"
              name="certificate_url"
              type="url"
              placeholder="https://.../certificado.pdf"
              value={formData.certificate_url}
              onChange={handleChange}
              disabled={isLoading}
            />
            {/* TODO: Add functionality to generate/upload certificate */}
          </div>

        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          {error && (
            <p className="text-sm text-red-600 dark:text-red-400">Erro: {error}</p>
          )}
          <div className="flex gap-2 ml-auto">
             <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
                Cancelar
             </Button>
             <Button type="submit" disabled={isLoading}>
                {isLoading ? (isEditing ? "Salvando..." : "Adicionando...") : (isEditing ? "Salvar Alterações" : "Adicionar Garantia")}
             </Button>
          </div>
        </CardFooter>
      </form>
    </Card>
  );
}

