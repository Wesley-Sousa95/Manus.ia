# /home/ubuntu/crm_dedetizadora_backend/src/routes/guarantees.py

import sys
import os
# Adiciona o diretório pai de \'src\' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, request, jsonify, Response, render_template_string
# Import Notification model
from src.models.models import db, Guarantee, Service, Client, Notification
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timedelta
from weasyprint import HTML, CSS
from weasyprint.text.fonts import FontConfiguration

guarantees_bp = Blueprint("guarantees_bp", __name__)

# Helper function to create/update guarantee expiry notification
def _create_or_update_expiry_notification(guarantee: Guarantee):
    try:
        # Calculate reminder date (e.g., 15 days before expiry)
        reminder_date = guarantee.end_date - timedelta(days=15)
        today = datetime.utcnow().date()

        # Only schedule if reminder date is in the future
        if reminder_date < today:
            # If guarantee already expired or reminder date passed, delete old notification
            Notification.query.filter_by(
                related_id=guarantee.guarantee_id,
                notification_type="GuaranteeExpiryReminder"
            ).delete()
            db.session.commit()
            return

        # Check if a notification already exists
        notification = Notification.query.filter_by(
            related_id=guarantee.guarantee_id,
            notification_type="GuaranteeExpiryReminder"
        ).first()

        # Correctly formatted message string
        message_text = f"A garantia do serviço #{guarantee.service_id} para {guarantee.service.client.name} expira em {guarantee.end_date.strftime('%d/%m/%Y')}."

        if notification:
            # Update existing notification
            notification.client_id = guarantee.service.client_id
            notification.scheduled_send_date = reminder_date
            notification.message = message_text # Use the correctly formatted string
            notification.status = "Pending" # Reset status if updated
        else:
            # Create new notification
            notification = Notification(
                client_id=guarantee.service.client_id,
                related_id=guarantee.guarantee_id,
                notification_type="GuaranteeExpiryReminder",
                message=message_text, # Use the correctly formatted string
                scheduled_send_date=reminder_date,
                status="Pending"
            )
            db.session.add(notification)
        
        db.session.commit()
        print(f"Scheduled/Updated expiry notification for guarantee {guarantee.guarantee_id} on {reminder_date}")

    except Exception as e:
        db.session.rollback()
        print(f"Error creating/updating expiry notification for guarantee {guarantee.guarantee_id}: {e}")
        # Log the error but don't fail the main guarantee operation

# --- Guarantee Routes ---

@guarantees_bp.route("/", methods=["POST"])
def create_guarantee():
    """Create a new guarantee for a service."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    required_fields = ["service_id", "start_date", "end_date"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": f"Missing required fields: {required_fields}"}), 400

    # Validate service exists (use joinedload for efficiency)
    service = Service.query.options(db.joinedload(Service.client)).get(data["service_id"])
    if not service:
        return jsonify({"error": "Service not found"}), 404

    # Check if guarantee already exists for this service
    existing_guarantee = Guarantee.query.filter_by(service_id=data["service_id"]).first()
    if existing_guarantee:
        return jsonify({"error": "Guarantee already exists for this service"}), 409 # Conflict

    try:
        start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
        end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"error": "Invalid date format. Use YYYY-MM-DD."}), 400

    if end_date <= start_date:
        return jsonify({"error": "End date must be after start date"}), 400

    # Calculate duration in months (approximate)
    duration_months = round((end_date - start_date).days / 30.44)

    new_guarantee = Guarantee(
        service_id=data["service_id"],
        start_date=start_date,
        end_date=end_date,
        duration_months=data.get("duration_months", duration_months), # Allow override
        certificate_url=data.get("certificate_url")
    )

    try:
        db.session.add(new_guarantee)
        db.session.flush() # Flush to get the new_guarantee ID
        
        # Create expiry notification after successful guarantee creation
        _create_or_update_expiry_notification(new_guarantee)
        
        db.session.commit() # Commit both guarantee and notification
        
        return jsonify({
            "message": "Guarantee created successfully",
            "guarantee": {
                "guarantee_id": new_guarantee.guarantee_id,
                "service_id": new_guarantee.service_id,
                "start_date": new_guarantee.start_date.isoformat(),
                "end_date": new_guarantee.end_date.isoformat(),
                "duration_months": new_guarantee.duration_months
            }
        }), 201
    except IntegrityError as e:
        db.session.rollback()
        return jsonify({"error": "Database integrity error", "details": str(e)}), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@guarantees_bp.route("/", methods=["GET"])
def get_guarantees():
    """Get a list of guarantees, potentially filtered."""
    # Filters (examples)
    status_filter = request.args.get("status") # e.g., active, expired, expiring_soon
    client_id_filter = request.args.get("client_id", type=int)
    today = datetime.utcnow().date()

    try:
        query = Guarantee.query.join(Service).join(Client)

        if client_id_filter:
            query = query.filter(Service.client_id == client_id_filter)

        guarantees_list = query.order_by(Guarantee.end_date).all()
        guarantees_data = []
        for g in guarantees_list:
            status = "Expired" if g.end_date < today else "Active"
            # Apply status filter after determining status
            if status_filter:
                if status_filter.lower() == "active" and status != "Active":
                    continue
                if status_filter.lower() == "expired" and status != "Expired":
                    continue
                if status_filter.lower() == "expiring_soon":
                    soon_date = today + timedelta(days=30)
                    if not (g.end_date >= today and g.end_date <= soon_date):
                        continue
            
            guarantees_data.append({
                "guarantee_id": g.guarantee_id,
                "service_id": g.service_id,
                "client_id": g.service.client_id,
                "client_name": g.service.client.name,
                "start_date": g.start_date.isoformat(),
                "end_date": g.end_date.isoformat(),
                "duration_months": g.duration_months,
                "status": status
            })
            
        return jsonify(guarantees_data), 200
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@guarantees_bp.route("/<int:guarantee_id>", methods=["GET"])
def get_guarantee_by_id(guarantee_id):
    """Get details of a specific guarantee."""
    try:
        # Use joinedload to efficiently fetch related service and client
        guarantee = Guarantee.query.options(
            db.joinedload(Guarantee.service).joinedload(Service.client)
        ).get(guarantee_id)
        
        if guarantee:
            today = datetime.utcnow().date()
            status = "Expired" if guarantee.end_date < today else "Active"
            guarantee_data = {
                "guarantee_id": guarantee.guarantee_id,
                "service_id": guarantee.service_id,
                "client_id": guarantee.service.client.client_id,
                "client_name": guarantee.service.client.name,
                "start_date": guarantee.start_date.isoformat(),
                "end_date": guarantee.end_date.isoformat(),
                "duration_months": guarantee.duration_months,
                "certificate_url": guarantee.certificate_url,
                "status": status,
                "created_at": guarantee.created_at.isoformat(),
                "updated_at": guarantee.updated_at.isoformat()
            }
            return jsonify(guarantee_data), 200
        else:
            return jsonify({"error": "Guarantee not found"}), 404
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@guarantees_bp.route("/<int:guarantee_id>", methods=["PUT"])
def update_guarantee(guarantee_id):
    """Update an existing guarantee."""
    try:
        # Use joinedload to get client info needed for notification
        guarantee = Guarantee.query.options(
            db.joinedload(Guarantee.service).joinedload(Service.client)
        ).get(guarantee_id)
        if not guarantee:
            return jsonify({"error": "Guarantee not found"}), 404

        data = request.get_json()
        if not data:
            return jsonify({"error": "No input data provided"}), 400

        dates_changed = False
        # Update fields
        try:
            if "start_date" in data:
                new_start_date = datetime.strptime(data["start_date"], "%Y-%m-%d").date()
                if new_start_date != guarantee.start_date:
                    guarantee.start_date = new_start_date
                    dates_changed = True
            if "end_date" in data:
                new_end_date = datetime.strptime(data["end_date"], "%Y-%m-%d").date()
                if new_end_date != guarantee.end_date:
                    guarantee.end_date = new_end_date
                    dates_changed = True
        except ValueError:
            return jsonify({"error": "Invalid date format. Use YYYY-MM-DD."}), 400

        if guarantee.end_date <= guarantee.start_date:
             return jsonify({"error": "End date must be after start date"}), 400

        # Recalculate duration if dates changed, unless duration is explicitly provided
        if dates_changed:
             duration_months_calc = round((guarantee.end_date - guarantee.start_date).days / 30.44)
             guarantee.duration_months = data.get("duration_months", duration_months_calc)
        elif "duration_months" in data:
             guarantee.duration_months = data["duration_months"]

        guarantee.certificate_url = data.get("certificate_url", guarantee.certificate_url)

        # Update expiry notification if dates changed
        if dates_changed:
            _create_or_update_expiry_notification(guarantee)

        db.session.commit()
        return jsonify({"message": "Guarantee updated successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@guarantees_bp.route("/<int:guarantee_id>", methods=["DELETE"])
def delete_guarantee(guarantee_id):
    """Delete a guarantee."""
    try:
        guarantee = Guarantee.query.get(guarantee_id)
        if not guarantee:
            return jsonify({"error": "Guarantee not found"}), 404

        # Delete associated expiry notification before deleting guarantee
        Notification.query.filter_by(
            related_id=guarantee.guarantee_id,
            notification_type="GuaranteeExpiryReminder"
        ).delete()
        
        db.session.delete(guarantee)
        db.session.commit()
        return jsonify({"message": "Guarantee deleted successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

# --- Certificate Generation Route ---

CERTIFICATE_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Certificado de Garantia</title>
    <style>
        @page {
            size: A4;
            margin: 2cm;
        }
        body {
            font-family: sans-serif; /* Use default sans-serif, WeasyPrint will handle it */
            line-height: 1.6;
            color: #333;
        }
        .container {
            border: 1px solid #ccc;
            padding: 30px;
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #0056b3; /* Example blue */
            margin-bottom: 30px;
        }
        p {
            margin-bottom: 15px;
        }
        .label {
            font-weight: bold;
            display: inline-block;
            width: 150px; /* Adjust as needed */
        }
        .value {
            display: inline-block;
        }
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 0.9em;
            color: #777;
        }
        .company-name {
            font-weight: bold;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Certificado de Garantia</h1>
        
        <p><span class="label">Cliente:</span> <span class="value">{{ client.name }}</span></p>
        <p><span class="label">Endereço:</span> <span class="value">{{ full_address }}</span></p>
        <p><span class="label">Serviço Realizado:</span> <span class="value">{{ service.pest_type_description or 'Controle de Pragas' }}</span></p>
        <p><span class="label">Data do Serviço:</span> <span class="value">{{ service.service_date.strftime('%d/%m/%Y') }}</span></p>
        <p><span class="label">ID do Serviço:</span> <span class="value">{{ service.service_id }}</span></p>
        
        <hr style="margin: 25px 0; border: 0; border-top: 1px solid #eee;">
        
        <p><span class="label">Início da Garantia:</span> <span class="value">{{ guarantee.start_date.strftime('%d/%m/%Y') }}</span></p>
        <p><span class="label">Fim da Garantia:</span> <span class="value">{{ guarantee.end_date.strftime('%d/%m/%Y') }}</span></p>
        <p><span class="label">Duração:</span> <span class="value">{{ guarantee.duration_months }} meses</span></p>
        
        <p style="margin-top: 25px;">
            Este certificado garante a qualidade do serviço de controle de pragas realizado no endereço e data acima especificados, 
            pelo período indicado. Condições e termos da garantia podem ser consultados junto à empresa.
        </p>
        
        <div class="footer">
            <p class="company-name">[Nome da Sua Dedetizadora Aqui]</p>
            <p>[Seu Endereço Aqui]</p>
            <p>[Seu Telefone Aqui] | [Seu Email Aqui]</p>
            <p>Emitido em: {{ today_date }}</p>
        </div>
    </div>
</body>
</html>
"""

@guarantees_bp.route("/<int:guarantee_id>/certificate", methods=["GET"])
def generate_certificate(guarantee_id):
    """Generate a PDF certificate for a specific guarantee."""
    try:
        guarantee = Guarantee.query.options(
            db.joinedload(Guarantee.service).joinedload(Service.client)
        ).get(guarantee_id)

        if not guarantee:
            return jsonify({"error": "Guarantee not found"}), 404

        client = guarantee.service.client
        service = guarantee.service

        full_address = ", ".join(filter(None, [
            client.address_street,
            client.address_number,
            client.address_complement,
            client.address_neighborhood,
            client.address_city,
            cl
(Content truncated due to size limit. Use line ranges to read in chunks)