// /home/ubuntu/crm_dedetizadora_frontend/src/app/page.tsx
import { redirect } from 'next/navigation';

export default function HomePage() {
  // For now, redirect users to the login page by default.
  // Later, this could check authentication status and redirect
  // to the dashboard if logged in.
  redirect('/login');

  // Or return a simple loading/welcome message if preferred before redirect
  // return <div>Carregando...</div>;
}

