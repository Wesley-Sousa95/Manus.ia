# /home/ubuntu/crm_dedetizadora_backend/src/routes/notifications.py

import sys
import os
# Adiciona o diretório pai de \'src\' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, request, jsonify
from src.models.models import db, Notification, Client, Guarantee, User # Import necessary models
from sqlalchemy.exc import IntegrityError
from datetime import datetime

notifications_bp = Blueprint("notifications_bp", __name__)

# --- Notification Routes (Primarily for viewing/managing system-generated notifications) ---

# Note: Notification creation might be handled internally by background jobs or triggers
# based on guarantee expiry dates or revisit schedules. Exposing a direct creation API
# might be less common unless for custom manual notifications.

@notifications_bp.route("/", methods=["GET"])
def get_notifications():
    """Get a list of notifications, potentially filtered."""
    # Filters (examples)
    status_filter = request.args.get("status") # Pending, Sent, Failed, Cancelled
    channel_filter = request.args.get("channel") # Email, WhatsApp, InApp, System
    client_id_filter = request.args.get("client_id", type=int)
    user_id_filter = request.args.get("user_id", type=int) # For internal notifications

    try:
        query = Notification.query

        if status_filter:
            query = query.filter(Notification.status == status_filter)
        if channel_filter:
            query = query.filter(Notification.channel == channel_filter)
        if client_id_filter:
            query = query.filter(Notification.client_id == client_id_filter)
        if user_id_filter:
            query = query.filter(Notification.user_id == user_id_filter)

        # Order by scheduled date or creation date
        notifications = query.order_by(Notification.scheduled_send_date.desc().nullslast(), Notification.created_at.desc()).all()

        notifications_data = [
            {
                "notification_id": n.notification_id,
                "client_id": n.client_id,
                "guarantee_id": n.guarantee_id,
                "user_id": n.user_id,
                "notification_type": n.notification_type,
                "channel": n.channel,
                "recipient": n.recipient,
                "subject": n.subject,
                "scheduled_send_date": n.scheduled_send_date.isoformat() if n.scheduled_send_date else None,
                "actual_send_date": n.actual_send_date.isoformat() if n.actual_send_date else None,
                "status": n.status,
                "created_at": n.created_at.isoformat()
            } for n in notifications
        ]
        return jsonify(notifications_data), 200
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@notifications_bp.route("/<int:notification_id>", methods=["GET"])
def get_notification_by_id(notification_id):
    """Get details of a specific notification."""
    try:
        notification = Notification.query.get(notification_id)
        if notification:
            notification_data = {
                "notification_id": notification.notification_id,
                "client_id": notification.client_id,
                "guarantee_id": notification.guarantee_id,
                "user_id": notification.user_id,
                "notification_type": notification.notification_type,
                "channel": notification.channel,
                "recipient": notification.recipient,
                "subject": notification.subject,
                "message": notification.message, # Include message body here
                "scheduled_send_date": notification.scheduled_send_date.isoformat() if notification.scheduled_send_date else None,
                "actual_send_date": notification.actual_send_date.isoformat() if notification.actual_send_date else None,
                "status": notification.status,
                "error_message": notification.error_message,
                "created_at": notification.created_at.isoformat(),
                "updated_at": notification.updated_at.isoformat()
            }
            return jsonify(notification_data), 200
        else:
            return jsonify({"error": "Notification not found"}), 404
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

# Optional: Route to manually trigger or update status (e.g., cancel a pending notification)
@notifications_bp.route("/<int:notification_id>/status", methods=["PUT"])
def update_notification_status(notification_id):
    """Manually update the status of a notification (e.g., cancel)."""
    notification = Notification.query.get(notification_id)
    if not notification:
        return jsonify({"error": "Notification not found"}), 404

    data = request.get_json()
    if not data or "status" not in data:
        return jsonify({"error": "Missing 'status' in request data"}), 400

    new_status = data["status"]
    allowed_statuses = ["Pending", "Sent", "Failed", "Cancelled"]
    if new_status not in allowed_statuses:
        return jsonify({"error": f"Invalid status. Must be one of {allowed_statuses}"}), 400

    # Add logic here if certain transitions are not allowed (e.g., cannot change from 'Sent')
    if notification.status == "Sent" and new_status != "Sent":
         return jsonify({"error": "Cannot change status of an already sent notification"}), 400

    try:
        notification.status = new_status
        # Optionally clear error message if cancelled or manually set to pending/sent
        if new_status in ["Cancelled", "Pending", "Sent"]:
            notification.error_message = None
        if new_status == "Sent" and not notification.actual_send_date:
             notification.actual_send_date = datetime.utcnow() # Mark as sent now

        db.session.commit()
        return jsonify({"message": f"Notification status updated to {new_status}"}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

# Deleting notifications might not be standard practice, maybe just cancel them.
# If deletion is needed, add a DELETE route similar to other blueprints.


