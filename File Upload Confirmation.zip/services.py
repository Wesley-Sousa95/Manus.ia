# /home/ubuntu/crm_dedetizadora_backend/src/routes/services.py

import sys
import os
# Adiciona o diretório pai de \'src\' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, request, jsonify
from src.models.models import db, Service, Client, User, ServicePhoto # Import necessary models
from sqlalchemy.exc import IntegrityError
from datetime import datetime

services_bp = Blueprint("services_bp", __name__)

# --- Service Routes ---

@services_bp.route("/", methods=["POST"])
def create_service():
    """Create a new service record."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    required_fields = ["client_id", "service_date"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": f"Missing required fields: {required_fields}"}), 400

    # Validate client exists
    client = Client.query.get(data["client_id"])
    if not client:
        return jsonify({"error": "Client not found"}), 404

    # TODO: Get performing user ID from auth token
    performed_by_user_id = data.get("performed_by_user_id")

    try:
        # Parse date string (assuming ISO format like YYYY-MM-DDTHH:MM:SS)
        service_date = datetime.fromisoformat(data["service_date"])
    except ValueError:
        return jsonify({"error": "Invalid date format for service_date. Use ISO format."}), 400

    new_service = Service(
        client_id=data["client_id"],
        service_date=service_date,
        pest_type_description=data.get("pest_type_description"),
        location_details=data.get("location_details"),
        products_used_description=data.get("products_used_description"),
        notes=data.get("notes"),
        performed_by_user_id=performed_by_user_id
    )

    try:
        db.session.add(new_service)
        db.session.commit()

        # Handle photos if provided (assuming list of URLs/paths)
        photos_data = data.get("photos", [])
        if photos_data:
            for photo_info in photos_data:
                if isinstance(photo_info, dict) and "photo_url" in photo_info:
                    new_photo = ServicePhoto(
                        service_id=new_service.service_id,
                        photo_url=photo_info["photo_url"],
                        description=photo_info.get("description")
                    )
                    db.session.add(new_photo)
                # Handle simple list of URLs if needed
                elif isinstance(photo_info, str):
                     new_photo = ServicePhoto(service_id=new_service.service_id, photo_url=photo_info)
                     db.session.add(new_photo)
            db.session.commit() # Commit photos after adding them

        # Fetch the service again to include relationships if needed for response
        created_service = Service.query.get(new_service.service_id)

        return jsonify({
            "message": "Service created successfully",
            "service": {
                "service_id": created_service.service_id,
                "client_id": created_service.client_id,
                "service_date": created_service.service_date.isoformat(),
                "pest_type_description": created_service.pest_type_description,
                "location_details": created_service.location_details,
                "photos": [p.photo_url for p in created_service.photos] # Example: return photo URLs
            }
        }), 201
    except IntegrityError as e:
        db.session.rollback()
        return jsonify({"error": "Database integrity error", "details": str(e)}), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@services_bp.route("/", methods=["GET"])
def get_services():
    """Get a list of services, potentially filtered by client_id."""
    client_id_filter = request.args.get("client_id", type=int)

    try:
        query = Service.query.order_by(Service.service_date.desc())
        if client_id_filter:
            query = query.filter(Service.client_id == client_id_filter)

        services = query.all()
        services_data = [
            {
                "service_id": service.service_id,
                "client_id": service.client_id,
                "client_name": service.client.name, # Access related client name
                "service_date": service.service_date.isoformat(),
                "pest_type_description": service.pest_type_description,
                "location_details": service.location_details,
                "performed_by_user_id": service.performed_by_user_id,
                "has_guarantee": service.guarantee is not None # Check if guarantee exists
            } for service in services
        ]
        return jsonify(services_data), 200
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@services_bp.route("/<int:service_id>", methods=["GET"])
def get_service_by_id(service_id):
    """Get details of a specific service."""
    try:
        service = Service.query.options(db.joinedload(Service.photos), db.joinedload(Service.guarantee)).get(service_id)
        if service:
            service_data = {
                "service_id": service.service_id,
                "client_id": service.client_id,
                "client_name": service.client.name,
                "service_date": service.service_date.isoformat(),
                "pest_type_description": service.pest_type_description,
                "location_details": service.location_details,
                "products_used_description": service.products_used_description,
                "notes": service.notes,
                "performed_by_user_id": service.performed_by_user_id,
                "photos": [
                    {"photo_id": p.photo_id, "photo_url": p.photo_url, "description": p.description}
                    for p in service.photos
                ],
                "guarantee": {
                    "guarantee_id": service.guarantee.guarantee_id,
                    "start_date": service.guarantee.start_date.isoformat(),
                    "end_date": service.guarantee.end_date.isoformat(),
                    "duration_months": service.guarantee.duration_months
                } if service.guarantee else None,
                "created_at": service.created_at.isoformat(),
                "updated_at": service.updated_at.isoformat()
            }
            return jsonify(service_data), 200
        else:
            return jsonify({"error": "Service not found"}), 404
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@services_bp.route("/<int:service_id>", methods=["PUT"])
def update_service(service_id):
    """Update an existing service."""
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({"error": "Service not found"}), 404

        data = request.get_json()
        if not data:
            return jsonify({"error": "No input data provided"}), 400

        # Update fields
        if "service_date" in data:
            try:
                service.service_date = datetime.fromisoformat(data["service_date"])
            except ValueError:
                return jsonify({"error": "Invalid date format for service_date. Use ISO format."}), 400

        service.pest_type_description = data.get("pest_type_description", service.pest_type_description)
        service.location_details = data.get("location_details", service.location_details)
        service.products_used_description = data.get("products_used_description", service.products_used_description)
        service.notes = data.get("notes", service.notes)
        # client_id and performed_by_user_id are less likely to be updated, handle if needed

        # TODO: Handle updates to photos (add/remove)

        db.session.commit()
        return jsonify({"message": "Service updated successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@services_bp.route("/<int:service_id>", methods=["DELETE"])
def delete_service(service_id):
    """Delete a service."""
    try:
        service = Service.query.get(service_id)
        if not service:
            return jsonify({"error": "Service not found"}), 404

        # Cascading delete should handle related photos, guarantee, notifications
        db.session.delete(service)
        db.session.commit()
        return jsonify({"message": "Service deleted successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

# --- Service Photo Routes (Example: Add photo to existing service) ---

@services_bp.route("/<int:service_id>/photos", methods=["POST"])
def add_photo_to_service(service_id):
    """Add a new photo to an existing service."""
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"error": "Service not found"}), 404

    data = request.get_json()
    if not data or "photo_url" not in data:
        return jsonify({"error": "Missing 'photo_url' in request data"}), 400

    try:
        new_photo = ServicePhoto(
            service_id=service_id,
            photo_url=data["photo_url"],
            description=data.get("description")
        )
        db.session.add(new_photo)
        db.session.commit()
        return jsonify({
            "message": "Photo added successfully",
            "photo": {
                "photo_id": new_photo.photo_id,
                "photo_url": new_photo.photo_url,
                "description": new_photo.description
            }
        }), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

# TODO: Add routes for deleting photos if needed


