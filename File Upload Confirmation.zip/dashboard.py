# /home/ubuntu/crm_dedetizadora_backend/src/routes/dashboard.py

import sys
import os
# Adiciona o diretório pai de 'src' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, jsonify
from src.models.models import db, Client, Service, Guarantee, Notification
from sqlalchemy import func
from datetime import datetime, timedelta

dashboard_bp = Blueprint("dashboard_bp", __name__)

@dashboard_bp.route("/summary", methods=["GET"])
def get_dashboard_summary():
    """Get summary statistics for the dashboard."""
    try:
        # Get current date for calculations
        today = datetime.utcnow().date()
        thirty_days_from_now = today + timedelta(days=30)
        
        # Count active clients (all clients for now)
        active_clients_count = Client.query.count()
        
        # Count active guarantees (end_date >= today)
        active_guarantees_count = Guarantee.query.filter(Guarantee.end_date >= today).count()
        
        # Count upcoming revisits (notifications scheduled in next 30 days)
        upcoming_revisits_count = Notification.query.filter(
            Notification.notification_type == "RevisitReminder",
            Notification.scheduled_send_date >= today,
            Notification.scheduled_send_date <= thirty_days_from_now
        ).count()
        
        # Return the summary data
        return jsonify({
            "active_clients": active_clients_count,
            "guarantees_active": active_guarantees_count,
            "revisits_upcoming": upcoming_revisits_count
        }), 200
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500
