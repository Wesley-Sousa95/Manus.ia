-- SQL Schema for CRM Dedetizadoras
-- Target Database: MySQL

-- Users Table: Stores login information and roles for system users.
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL, -- Store hashed passwords
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `role` ENUM('admin', 'manager', 'technician') NOT NULL DEFAULT 'technician',
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Clients Table: Stores information about the customers.
CREATE TABLE IF NOT EXISTS `clients` (
  `client_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(20),
  `email` VARCHAR(100),
  `address_street` VARCHAR(255),
  `address_number` VARCHAR(20),
  `address_complement` VARCHAR(100),
  `address_neighborhood` VARCHAR(100),
  `address_city` VARCHAR(100),
  `address_state` VARCHAR(50),
  `address_zipcode` VARCHAR(15),
  `address_latitude` DECIMAL(10, 8), -- For Google Maps integration
  `address_longitude` DECIMAL(11, 8), -- For Google Maps integration
  `segment` ENUM('Residencial', 'Comercial', 'Condomínio', 'Industrial') NOT NULL,
  `created_by_user_id` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by_user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pests Table: Optional table to standardize pest types.
CREATE TABLE IF NOT EXISTS `pests` (
  `pest_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products Table: Optional table to standardize products used.
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Services Table: Records details of each service performed.
CREATE TABLE IF NOT EXISTS `services` (
  `service_id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT NOT NULL,
  `service_date` DATETIME NOT NULL,
  `pest_type_description` VARCHAR(255), -- Free text if not using pests table
  -- `pest_id` INT, -- Uncomment if using pests table
  `location_details` VARCHAR(255) COMMENT 'Specific location within the client address, e.g., Kitchen, Garden',
  `products_used_description` TEXT, -- Free text if not using products table
  -- Consider a linking table if multiple products are used and Products table exists
  `notes` TEXT,
  `performed_by_user_id` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients`(`client_id`) ON DELETE CASCADE, -- Cascade delete if client is removed
  FOREIGN KEY (`performed_by_user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
  -- FOREIGN KEY (`pest_id`) REFERENCES `pests`(`pest_id`) ON DELETE SET NULL -- Uncomment if using pests table
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Service Photos Table: Stores paths/URLs to before/after photos for services.
CREATE TABLE IF NOT EXISTS `service_photos` (
  `photo_id` INT AUTO_INCREMENT PRIMARY KEY,
  `service_id` INT NOT NULL,
  `photo_url` VARCHAR(512) NOT NULL COMMENT 'URL or path to the stored image file',
  `description` VARCHAR(100) COMMENT 'e.g., Before, After, Evidence',
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`service_id`) REFERENCES `services`(`service_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Guarantees Table: Manages service guarantees.
CREATE TABLE IF NOT EXISTS `guarantees` (
  `guarantee_id` INT AUTO_INCREMENT PRIMARY KEY,
  `service_id` INT NOT NULL UNIQUE, -- Assuming one guarantee per service
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `duration_months` INT COMMENT 'Calculated or stored duration in months',
  `certificate_url` VARCHAR(512) COMMENT 'Path/URL to the generated certificate PDF',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`service_id`) REFERENCES `services`(`service_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notifications Table: Stores scheduled and sent notifications.
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT,
  `guarantee_id` INT,
  `user_id` INT COMMENT 'User to notify internally (e.g., revisit reminder)',
  `notification_type` ENUM('GuaranteeExpiry', 'RevisitReminder', 'Custom') NOT NULL,
  `channel` ENUM('Email', 'WhatsApp', 'InApp', 'System') NOT NULL,
  `recipient` VARCHAR(255) COMMENT 'Email address, phone number, or user identifier',
  `subject` VARCHAR(255),
  `message` TEXT NOT NULL,
  `scheduled_send_date` TIMESTAMP,
  `actual_send_date` TIMESTAMP NULL,
  `status` ENUM('Pending', 'Sent', 'Failed', 'Cancelled') NOT NULL DEFAULT 'Pending',
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients`(`client_id`) ON DELETE CASCADE,
  FOREIGN KEY (`guarantee_id`) REFERENCES `guarantees`(`guarantee_id`) ON DELETE SET NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add Indexes for performance
ALTER TABLE `clients` ADD INDEX `idx_client_name` (`name`);
ALTER TABLE `clients` ADD INDEX `idx_client_phone` (`phone`);
ALTER TABLE `clients` ADD INDEX `idx_client_email` (`email`);
ALTER TABLE `services` ADD INDEX `idx_service_date` (`service_date`);
ALTER TABLE `guarantees` ADD INDEX `idx_guarantee_end_date` (`end_date`);
ALTER TABLE `notifications` ADD INDEX `idx_notification_status_schedule` (`status`, `scheduled_send_date`);

-- Sample Data (Optional - for testing)
-- INSERT INTO `users` (`username`, `password_hash`, `full_name`, `email`, `role`) VALUES
-- ('admin', 'hashed_password_admin', 'Admin User', 'admin@dedetizadora.com', 'admin'),
-- ('tecnico1', 'hashed_password_tec1', 'Tecnico Um', 'tecnico1@dedetizadora.com', 'technician');

-- INSERT INTO `clients` (`name`, `phone`, `email`, `address_street`, `address_city`, `segment`, `created_by_user_id`) VALUES
-- ('Cliente Exemplo Residencial', '11999998888', 'residencial@email.com', 'Rua das Flores, 123', 'São Paulo', 'Residencial', 1),
-- ('Empresa Exemplo Comercial', '1155554444', 'comercial@empresa.com', 'Av. Principal, 456', 'São Paulo', 'Comercial', 1);


