# /home/ubuntu/crm_dedetizadora_backend/src/routes/auth.py

import sys
import os
# Adiciona o diretório pai de \'src\' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.models.models import db, User
from sqlalchemy.exc import IntegrityError

auth_bp = Blueprint("auth_bp", __name__)

# --- Authentication Routes ---

@auth_bp.route("/register", methods=["POST"])
def register_user():
    """Register a new user (potentially restricted to admins later)."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    required_fields = ["username", "password", "full_name", "email", "role"]
    if not all(field in data for field in required_fields):
        return jsonify({"error": f"Missing required fields: {required_fields}"}), 400

    username = data["username"]
    password = data["password"]
    full_name = data["full_name"]
    email = data["email"]
    role = data.get("role", "technician") # Default role

    if role not in ["admin", "manager", "technician"]:
        return jsonify({"error": "Invalid role specified"}), 400

    # Check if username or email already exists
    if User.query.filter((User.username == username) | (User.email == email)).first():
        return jsonify({"error": "Username or email already exists"}), 409

    # Hash the password
    password_hash = generate_password_hash(password)

    new_user = User(
        username=username,
        password_hash=password_hash,
        full_name=full_name,
        email=email,
        role=role
    )

    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({
            "message": "User registered successfully",
            "user": {"user_id": new_user.user_id, "username": new_user.username, "role": new_user.role}
        }), 201
    except IntegrityError as e:
        db.session.rollback()
        return jsonify({"error": "Database integrity error", "details": str(e)}), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@auth_bp.route("/login", methods=["POST"])
def login_user():
    """Authenticate a user and return a JWT access token."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    user = User.query.filter_by(username=username, is_active=True).first()

    if user and check_password_hash(user.password_hash, password):
        # Identity can be the user ID or any other unique identifier
        # Include role in the token claims for frontend authorization
        additional_claims = {"role": user.role, "full_name": user.full_name}
        access_token = create_access_token(identity=user.user_id, additional_claims=additional_claims)
        return jsonify(access_token=access_token), 200
    else:
        return jsonify({"error": "Invalid username or password"}), 401 # Unauthorized

@auth_bp.route("/profile", methods=["GET"])
@jwt_required()
def get_user_profile():
    """Get the profile of the currently logged-in user."""
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    if not user:
        # This should ideally not happen if the token is valid
        return jsonify({"error": "User not found"}), 404

    return jsonify({
        "user_id": user.user_id,
        "username": user.username,
        "full_name": user.full_name,
        "email": user.email,
        "role": user.role,
        "is_active": user.is_active
    }), 200

# TODO: Add routes for password reset, user management (activate/deactivate, change role) - potentially in a separate users_bp


