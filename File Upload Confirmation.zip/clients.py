# /home/ubuntu/crm_dedetizadora_backend/src/routes/clients.py

import sys
import os
# Adiciona o diretório pai de 'src' ao sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

from flask import Blueprint, request, jsonify
from src.models.models import db, Client, User # Import necessary models
from sqlalchemy.exc import IntegrityError

clients_bp = Blueprint('clients_bp', __name__)

# --- Client Routes ---

@clients_bp.route('/', methods=['POST'])
def create_client():
    """Create a new client."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "No input data provided"}), 400

    # Basic validation (more can be added)
    required_fields = ['name', 'segment']
    if not all(field in data for field in required_fields):
        return jsonify({"error": f"Missing required fields: {required_fields}"}), 400

    # TODO: Add logic to get current user ID for created_by_user_id
    # For now, setting it to None or a default if needed
    created_by_user_id = data.get('created_by_user_id') # Or get from auth token later

    new_client = Client(
        name=data['name'],
        phone=data.get('phone'),
        email=data.get('email'),
        address_street=data.get('address_street'),
        address_number=data.get('address_number'),
        address_complement=data.get('address_complement'),
        address_neighborhood=data.get('address_neighborhood'),
        address_city=data.get('address_city'),
        address_state=data.get('address_state'),
        address_zipcode=data.get('address_zipcode'),
        address_latitude=data.get('address_latitude'),
        address_longitude=data.get('address_longitude'),
        segment=data['segment'],
        created_by_user_id=created_by_user_id
    )

    try:
        db.session.add(new_client)
        db.session.commit()
        # Return the created client data, excluding sensitive info if any
        return jsonify({
            "message": "Client created successfully",
            "client": {
                "client_id": new_client.client_id,
                "name": new_client.name,
                "phone": new_client.phone,
                "email": new_client.email,
                "segment": new_client.segment,
                "created_at": new_client.created_at.isoformat()
            }
        }), 201
    except IntegrityError as e:
        db.session.rollback()
        # Check for specific constraint violations if needed
        return jsonify({"error": "Database integrity error", "details": str(e)}), 409 # Conflict
    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@clients_bp.route('/', methods=['GET'])
def get_clients():
    """Get a list of all clients, potentially with filters."""
    # TODO: Implement filtering, pagination
    try:
        clients = Client.query.order_by(Client.name).all()
        clients_data = [
            {
                "client_id": client.client_id,
                "name": client.name,
                "phone": client.phone,
                "email": client.email,
                "segment": client.segment,
                "address_city": client.address_city,
                "address_state": client.address_state,
                "created_at": client.created_at.isoformat()
            } for client in clients
        ]
        return jsonify(clients_data), 200
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@clients_bp.route('/<int:client_id>', methods=['GET'])
def get_client_by_id(client_id):
    """Get details of a specific client."""
    try:
        client = Client.query.get(client_id)
        if client:
            client_data = {
                "client_id": client.client_id,
                "name": client.name,
                "phone": client.phone,
                "email": client.email,
                "address_street": client.address_street,
                "address_number": client.address_number,
                "address_complement": client.address_complement,
                "address_neighborhood": client.address_neighborhood,
                "address_city": client.address_city,
                "address_state": client.address_state,
                "address_zipcode": client.address_zipcode,
                "address_latitude": float(client.address_latitude) if client.address_latitude else None,
                "address_longitude": float(client.address_longitude) if client.address_longitude else None,
                "segment": client.segment,
                "created_by_user_id": client.created_by_user_id,
                "created_at": client.created_at.isoformat(),
                "updated_at": client.updated_at.isoformat()
                # TODO: Add related services/guarantees if needed
            }
            return jsonify(client_data), 200
        else:
            return jsonify({"error": "Client not found"}), 404
    except Exception as e:
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@clients_bp.route('/<int:client_id>', methods=['PUT'])
def update_client(client_id):
    """Update an existing client."""
    try:
        client = Client.query.get(client_id)
        if not client:
            return jsonify({"error": "Client not found"}), 404

        data = request.get_json()
        if not data:
            return jsonify({"error": "No input data provided"}), 400

        # Update fields if provided in the request
        client.name = data.get('name', client.name)
        client.phone = data.get('phone', client.phone)
        client.email = data.get('email', client.email)
        client.address_street = data.get('address_street', client.address_street)
        client.address_number = data.get('address_number', client.address_number)
        client.address_complement = data.get('address_complement', client.address_complement)
        client.address_neighborhood = data.get('address_neighborhood', client.address_neighborhood)
        client.address_city = data.get('address_city', client.address_city)
        client.address_state = data.get('address_state', client.address_state)
        client.address_zipcode = data.get('address_zipcode', client.address_zipcode)
        client.address_latitude = data.get('address_latitude', client.address_latitude)
        client.address_longitude = data.get('address_longitude', client.address_longitude)
        client.segment = data.get('segment', client.segment)
        # created_by_user_id is usually not updated

        db.session.commit()
        return jsonify({"message": "Client updated successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500

@clients_bp.route('/<int:client_id>', methods=['DELETE'])
def delete_client(client_id):
    """Delete a client."""
    try:
        client = Client.query.get(client_id)
        if not client:
            return jsonify({"error": "Client not found"}), 404

        # Cascading delete should handle related services, photos, guarantees, notifications
        db.session.delete(client)
        db.session.commit()
        return jsonify({"message": "Client deleted successfully"}), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": "An unexpected error occurred", "details": str(e)}), 500


