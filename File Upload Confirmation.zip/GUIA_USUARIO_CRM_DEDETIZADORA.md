# Guia do Usuário - CRM para Dedetizadoras

Este guia fornece instruções detalhadas sobre como utilizar o sistema CRM para Dedetizadoras, incluindo todas as funcionalidades disponíveis e fluxos de trabalho recomendados.

## Índice

1. [Acesso ao Sistema](#acesso-ao-sistema)
2. [Dashboard](#dashboard)
3. [Gerenciamento de Clientes](#gerenciamento-de-clientes)
4. [Gerenciamento de Serviços](#gerenciamento-de-serviços)
5. [Gerenciamento de Garantias](#gerenciamento-de-garantias)
6. [Notificações](#notificações)
7. [Administração do Sistema](#administração-do-sistema)

## Acesso ao Sistema

### Login

1. Acesse a URL do sistema fornecida pelo administrador
2. Na tela de login, insira seu nome de usuário e senha
3. Clique no botão "Entrar"

**Observação:** Se você esqueceu sua senha, entre em contato com o administrador do sistema para redefinição.

## Dashboard

O Dashboard é a tela inicial após o login e fornece uma visão geral das principais métricas e atividades do sistema:

- **Resumo de Clientes:** Total de clientes ativos, segmentados por tipo (Residencial, Comercial, Condomínio, Industrial)
- **Serviços Recentes:** Lista dos últimos serviços realizados
- **Garantias Ativas:** Número total de garantias ativas
- **Garantias a Vencer:** Lista de garantias que vencerão nos próximos 30 dias
- **Revisitas Programadas:** Lista de revisitas programadas para os próximos dias

Utilize o Dashboard para monitorar o desempenho geral e identificar ações prioritárias.

## Gerenciamento de Clientes

### Visualizar Lista de Clientes

1. Clique em "Clientes" no menu lateral
2. A lista de clientes será exibida com informações básicas
3. Utilize os filtros no topo da página para refinar a busca por nome, segmento ou cidade

### Adicionar Novo Cliente

1. Na página de lista de clientes, clique no botão "Novo Cliente"
2. Preencha o formulário com os dados do cliente:
   - Nome (obrigatório)
   - Telefone
   - Email
   - Endereço completo (rua, número, complemento, bairro, cidade, estado, CEP)
   - Segmento (Residencial, Comercial, Condomínio ou Industrial)
3. Clique em "Salvar"

### Visualizar Detalhes do Cliente

1. Na lista de clientes, clique no nome do cliente desejado
2. A página de detalhes mostrará todas as informações do cliente, incluindo:
   - Dados de contato
   - Endereço (com visualização no mapa)
   - Histórico de serviços
   - Garantias ativas

### Editar Cliente

1. Na página de detalhes do cliente, clique no botão "Editar"
2. Atualize as informações necessárias
3. Clique em "Salvar"

### Localizar Cliente no Mapa

1. Na página de detalhes do cliente, a localização será exibida automaticamente no mapa se as coordenadas estiverem disponíveis
2. Utilize os controles do mapa para zoom e navegação

## Gerenciamento de Serviços

### Visualizar Lista de Serviços

1. Clique em "Serviços" no menu lateral
2. A lista de serviços será exibida com informações básicas
3. Utilize os filtros para buscar por cliente, data ou tipo de serviço

### Registrar Novo Serviço

1. Na página de lista de serviços, clique no botão "Novo Serviço"
2. Selecione o cliente (obrigatório)
3. Preencha os detalhes do serviço:
   - Data e hora do serviço
   - Tipo de praga/serviço
   - Localização específica (ex: cozinha, jardim)
   - Produtos utilizados
   - Observações
4. Adicione fotos do serviço (opcional)
5. Clique em "Salvar"

### Visualizar Detalhes do Serviço

1. Na lista de serviços, clique no serviço desejado
2. A página de detalhes mostrará todas as informações do serviço, incluindo:
   - Cliente atendido
   - Data e detalhes do serviço
   - Fotos anexadas
   - Garantia associada (se existir)

### Anexar Fotos ao Serviço

1. Na página de detalhes do serviço, clique em "Adicionar Fotos"
2. Selecione as fotos do seu dispositivo
3. Adicione uma descrição para cada foto (ex: "Antes", "Depois", "Evidência")
4. Clique em "Enviar"

## Gerenciamento de Garantias

### Visualizar Lista de Garantias

1. Clique em "Garantias" no menu lateral
2. A lista de garantias será exibida com informações básicas
3. Utilize os filtros para buscar por status (ativa, expirada, a vencer) ou cliente

### Criar Nova Garantia

1. Na página de detalhes do serviço, clique em "Criar Garantia"
2. Defina os parâmetros da garantia:
   - Data de início (padrão: data do serviço)
   - Data de término
   - Duração em meses (calculada automaticamente)
3. Clique em "Salvar"

### Gerar Certificado de Garantia

1. Na página de detalhes da garantia, clique em "Gerar Certificado"
2. O sistema gerará um PDF com o certificado de garantia
3. O certificado pode ser baixado, impresso ou enviado por email

### Gerenciar Garantias a Vencer

1. No Dashboard, verifique a seção "Garantias a Vencer"
2. Clique em uma garantia para ver seus detalhes
3. Entre em contato com o cliente para agendar uma revisita ou renovação

## Notificações

### Visualizar Notificações

1. Clique no ícone de sino no canto superior direito
2. A lista de notificações será exibida
3. As notificações não lidas aparecerão destacadas

### Tipos de Notificações

- **Garantias a Vencer:** Alertas sobre garantias que expirarão em breve
- **Revisitas Programadas:** Lembretes sobre revisitas agendadas
- **Notificações do Sistema:** Informações sobre atualizações ou manutenções

## Administração do Sistema

### Gerenciar Usuários (apenas para administradores)

1. Clique em "Administração" no menu lateral
2. Selecione "Usuários"
3. Visualize, adicione, edite ou desative usuários do sistema

### Configurações do Sistema (apenas para administradores)

1. Clique em "Administração" no menu lateral
2. Selecione "Configurações"
3. Ajuste parâmetros como:
   - Duração padrão de garantias
   - Antecedência para notificações de garantias a vencer
   - Informações da empresa para certificados

## Dicas e Boas Práticas

1. **Mantenha os dados atualizados:** Informações precisas de clientes garantem comunicação eficiente
2. **Documente com fotos:** Anexe fotos antes e depois dos serviços para referência futura
3. **Monitore o Dashboard diariamente:** Identifique oportunidades de negócio e tarefas pendentes
4. **Utilize filtros de busca:** Para encontrar rapidamente informações em grandes volumes de dados
5. **Gerencie proativamente as garantias:** Entre em contato com clientes antes do vencimento para agendar revisitas
