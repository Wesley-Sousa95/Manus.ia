// /home/ubuntu/crm_dedetizadora_frontend/src/components/services/ServiceForm.tsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Assuming Select is available

// Define structure for service form data
interface ServiceFormData {
  client_id: number | "";
  service_date: string; // Store as string for input type="datetime-local"
  pest_type_description?: string;
  location_details?: string;
  products_used_description?: string;
  notes?: string;
  // performed_by_user_id will likely come from logged-in user context
  // photos might be handled separately (upload component)
}

// Define structure for Client lookup
interface ClientLookup {
    client_id: number;
    name: string;
}

interface ServiceFormProps {
  initialData?: ServiceFormData & { service_id?: number };
  clients: ClientLookup[]; // Pass list of clients for selection
  isEditing: boolean;
  onSubmit: (data: ServiceFormData) => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

export default function ServiceForm({
  initialData,
  clients,
  isEditing,
  onSubmit,
  isLoading,
  error,
}: ServiceFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState<ServiceFormData>({
    client_id: "",
    service_date: new Date().toISOString().slice(0, 16), // Default to now in YYYY-MM-DDTHH:MM format
    pest_type_description: "",
    location_details: "",
    products_used_description: "",
    notes: "",
    ...(initialData || {}),
  });

  useEffect(() => {
    if (initialData) {
      setFormData({
        client_id: initialData.client_id || "",
        // Format date from ISO string to datetime-local compatible string if needed
        service_date: initialData.service_date ? new Date(initialData.service_date).toISOString().slice(0, 16) : new Date().toISOString().slice(0, 16),
        pest_type_description: initialData.pest_type_description || "",
        location_details: initialData.location_details || "",
        products_used_description: initialData.products_used_description || "",
        notes: initialData.notes || "",
      });
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleClientSelectChange = (value: string) => {
    const clientId = parseInt(value, 10);
    setFormData((prev) => ({ ...prev, client_id: isNaN(clientId) ? "" : clientId }));
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    // Convert date string back to full ISO format for backend if necessary
    const dataToSend = {
        ...formData,
        service_date: new Date(formData.service_date).toISOString()
    };
    await onSubmit(dataToSend);
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>{isEditing ? "Editar Serviço" : "Registrar Novo Serviço"}</CardTitle>
        <CardDescription>
          Preencha os detalhes do serviço realizado.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Column 1 */}
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="client_id">Cliente *</Label>
              <Select
                required
                value={formData.client_id?.toString() || ""}
                onValueChange={handleClientSelectChange}
                disabled={isLoading || isEditing} // Disable client change when editing?
              >
                <SelectTrigger id="client_id" name="client_id">
                  <SelectValue placeholder="Selecione o cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map(client => (
                    <SelectItem key={client.client_id} value={client.client_id.toString()}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="service_date">Data e Hora do Serviço *</Label>
              <Input
                id="service_date"
                name="service_date"
                type="datetime-local"
                required
                value={formData.service_date}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="pest_type_description">Tipo de Praga / Serviço</Label>
              <Input
                id="pest_type_description"
                name="pest_type_description"
                placeholder="Ex: Baratas, Ratos, Descupinização"
                value={formData.pest_type_description}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>

             <div className="grid gap-2">
              <Label htmlFor="location_details">Local da Aplicação</Label>
              <Input
                id="location_details"
                name="location_details"
                placeholder="Ex: Cozinha, Jardim, Forro, Empresa toda"
                value={formData.location_details}
                onChange={handleChange}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Column 2 */}
          <div className="space-y-4">
             <div className="grid gap-2">
              <Label htmlFor="products_used_description">Produtos Utilizados</Label>
              <Textarea
                id="products_used_description"
                name="products_used_description"
                placeholder="Descreva os produtos e dosagens aplicados"
                value={formData.products_used_description}
                onChange={handleChange}
                disabled={isLoading}
                rows={3}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="notes">Observações Adicionais</Label>
              <Textarea
                id="notes"
                name="notes"
                placeholder="Instruções para o cliente, pontos de atenção, etc."
                value={formData.notes}
                onChange={handleChange}
                disabled={isLoading}
                rows={5}
              />
            </div>

            {/* TODO: Add Photo Upload Component Here */}

          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t pt-6">
          {error && (
            <p className="text-sm text-red-600 dark:text-red-400">Erro: {error}</p>
          )}
          <div className="flex gap-2 ml-auto">
             <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
                Cancelar
             </Button>
             <Button type="submit" disabled={isLoading}>
                {isLoading ? (isEditing ? "Salvando..." : "Registrando...") : (isEditing ? "Salvar Alterações" : "Registrar Serviço")}
             </Button>
          </div>
        </CardFooter>
      </form>
    </Card>
  );
}

