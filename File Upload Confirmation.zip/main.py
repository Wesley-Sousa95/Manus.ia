# /home/ubuntu/crm_dedetizadora_backend/src/main.py
import os
import sys
import urllib.parse # Import urllib
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
# Import the db instance and all models from the new models file
from src.models.models import db, User, Client, Pest, Product, Service, ServicePhoto, Guarantee, Notification
from flask_jwt_extended import JWTManager

# Import blueprints
from src.routes.auth import auth_bp
from src.routes.clients import clients_bp
from src.routes.services import services_bp
from src.routes.guarantees import guarantees_bp
from src.routes.notifications import notifications_bp
from src.routes.dashboard import dashboard_bp # Import the new dashboard blueprint

app = Flask(__name__, static_folder=None) # Disable default static folder handling for API
app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "default_secret_key_for_dev_!@#$%") # Use env var for secret key

# Configure JWT
app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "jwt_secret_key_for_dev_!@#$%")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = 86400  # 24 hours in seconds
jwt = JWTManager(app)

# Enable and configure database - PostgreSQL (Supabase) connection
# URL-encode the password to handle special characters like '@'
db_user = os.getenv('DB_USERNAME', 'postgres.qlhujkcbkxjuolesonne')
db_password_raw = os.getenv('DB_PASSWORD', 'Wesl@2211')
db_password_encoded = urllib.parse.quote_plus(db_password_raw)
db_host = os.getenv('DB_HOST', 'aws-0-sa-east-1.pooler.supabase.com')
db_port = os.getenv('DB_PORT', '5432')
db_name = os.getenv('DB_NAME', 'postgres')

app.config["SQLALCHEMY_DATABASE_URI"] = f"postgresql://{db_user}:{db_password_encoded}@{db_host}:{db_port}/{db_name}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Create database tables if they don't exist
with app.app_context():
    print("Creating database tables...")
    db.create_all()
    print("Database tables created (if they didn't exist).")

# Register Blueprints for API routes
app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(clients_bp, url_prefix="/api/clients")
app.register_blueprint(services_bp, url_prefix="/api/services")
app.register_blueprint(guarantees_bp, url_prefix="/api/guarantees")
app.register_blueprint(notifications_bp, url_prefix="/api/notifications")
app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard") # Register the dashboard blueprint

# Simple health check endpoint
@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({"status": "healthy"}), 200

# CORS configuration for development
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
    return response

if __name__ == "__main__":
    # Run on 0.0.0.0 to be accessible externally (e.g., from frontend dev server or deployment)
    # Use port 5001 to avoid potential conflicts with other services often using 5000
    app.run(host="0.0.0.0", port=5001, debug=True) # Changed port to 5001
